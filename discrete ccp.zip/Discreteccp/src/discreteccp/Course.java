package discreteccp;

import java.util.HashSet;
import java.util.Set;

public class Course {
	String name;
	int capacity;
	int enroll;
	int minyear;
	Set<String>prerequisites;
	
	public Course(String name,int capacity,int minyear) {
		this.name=name;
		this.capacity=capacity;
		this.minyear=minyear;
		this.enroll=0;
		this.prerequisites=new HashSet<>();
		
		
	}

}
