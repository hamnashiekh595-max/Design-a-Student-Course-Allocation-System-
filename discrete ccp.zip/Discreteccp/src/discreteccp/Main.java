package discreteccp;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		Course dsa = new Course("DSA", 2, 2);
        Course ml = new Course("ML", 2, 3);
        Course capstone = new Course("Capstone", 1, 4);

        ml.prerequisites.add("DSA");

        Set<Course> courses = new HashSet<>();
        courses.add(dsa);
        courses.add(ml);
        courses.add(capstone);
        Set<Student> students = new HashSet<>();

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        for (int i = 1; i <= n; i++) {

            System.out.println("\nStudent " + i);
            System.out.print("Enter year: ");
            int year = sc.nextInt();
            sc.nextLine();

            Student s = new Student(i, year);

            System.out.print("Enter number of completed courses: ");
            int k = sc.nextInt();
            sc.nextLine();

            for (int j = 0; j < k; j++) {
                System.out.print("Enter course name: ");
                s.completedcourse.add(sc.nextLine());
            }

            students.add(s);
        }
        Allocate.allocate(students, courses);
        System.out.println("\n--- COURSE ALLOCATION RESULT ---");
        for (Student s : students) {
            System.out.println("Student " + s.id + " allocated: " + s.allocatedcourse);
        }

        System.out.println("\n--- COURSE CAPACITY STATUS ---");
        for (Course c : courses) {
            System.out.println(c.name + " → " + c.enroll + "/" + c.capacity);
        }

        System.out.println("\n--- REJECTION REPORT ---");
        for (Student s : students) {
            for (Course c : courses) {
                if (!s.allocatedcourse.contains(c.name)) {
                    System.out.println("Student " + s.id + " rejected for " + c.name + 
                                       " → " + getRejectionReason(s, c));
                }
            }
        }
        }
        public static String getRejectionReason(Student s, Course c) {
            if (s.year < c.minyear)
                return "Year requirement not met";
            if (s.completedcourse.containsAll(c.prerequisites))
                return "Prerequisites not completed";
            if (c.enroll >= c.capacity)
                return "Course capacity full";
            return "Eligible"; 
        
	}
	}


