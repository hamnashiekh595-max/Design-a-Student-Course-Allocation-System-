package discreteccp;

import java.util.HashSet;
import java.util.Set;

public class Student {
	int id;
	int year;
    Set<String>completedcourse;
	Set<String>allocatedcourse;
	
	public Student(int id,int year) {
		this.id=id;
		this.year=year;
		this.allocatedcourse=new HashSet<>();
		this.completedcourse=new HashSet<>();
		
	}

}
