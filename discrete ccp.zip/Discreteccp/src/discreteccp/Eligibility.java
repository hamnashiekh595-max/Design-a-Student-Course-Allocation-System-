package discreteccp;

public class Eligibility {
	public static boolean iseligible(Student s,Course c) {
		if(s.year<c.minyear)
			return false;
		
		if (!s.completedcourse.containsAll(c.prerequisites))
            return false;
		
		 if (c.enroll>= c.capacity)
	            return false;

	        return true;
		
		
	}

}
