package discreteccp;

import java.util.Set;

public class Allocate {
	public static void allocate(Set<Student> students, Set<Course> courses) {
		for (Student s : students) {
            for (Course c : courses) {

                if (Eligibility.iseligible(s, c)) {
                    s.allocatedcourse.add(c.name);
                    c.enroll++;
                }
            }
        }
		
	}

}
